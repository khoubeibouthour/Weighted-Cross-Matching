# OpenFace API Docs

+ Create `openface.rst` with `sphinx-apidoc -o . ../openface`.
